﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour {
	
	public GameObject infoUIPrefab;


	public InfoUI info;



	public void Awake(){
		info = Instantiate (infoUIPrefab, transform).GetComponent<InfoUI>();
		//info.SetData(currentPlanet);
	
	}

	public void Update(){
		if (Manager.currentAstro != null)
			info.SetData (Manager.currentAstro);
		else
			info.SetData (Manager.currentOrbitAstro, 0);
	}


}
