﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlanetarySystem : MonoBehaviour
{
    [SerializeField]
    public SunInfo sun;
    public float scale = 1000000;
    public float timer = 0;
    public float timerMultiplier = 3600;
    public bool simulate = true;

    public Gradient orbitColor;
    public DragCameraLook cam;

    public GameObject uiPrefab;
    public AstroInfo current;

	[HideInInspector]
	public OrbitAstroInfo orbitAstroCurrent;
	

    [SerializeField]
    public OrbitAstroInfo rocket;

    public Light directionalLight;

    [Header("UI")]
    public Text text;

    public bool createTransfer;


    public void Awake()
    {
		Manager.planetarySystem = this;
	
		Manager.cam = cam;

        GameObject systemContainer = new GameObject("_planetary_system");
        GameObject sunContainer = new GameObject("_sun");
        sunContainer.transform.parent = systemContainer.transform;
        sun.graphic.Create(sun, scale, sunContainer.transform);
        current = sun;

        sun.references.CreateUI(uiPrefab, sunContainer.transform);
		Utilities.AddActionToButton(sun.references.button, () => Manager.ChangeTarget(sun));
		Manager.ChangeTarget(sun);



        foreach (var planet in sun.planets)
        {

            GameObject planetContainer = new GameObject("_" + planet.name);
            planetContainer.transform.parent = systemContainer.transform;
            planet.graphic.Create(planet, scale, planetContainer.transform);
            planet.InitReferencesAndVariables();
            planet.references.CreateUI(uiPrefab, planetContainer.transform);
			Utilities.AddActionToButton(planet.references.button, () => Manager.ChangeTarget(planet,SpacePhysics.AstroType.Planet));
            planet.SetPosition(scale);
            SpacePhysics.CalculateOrbitVariables(planet, sun);
            SpacePhysics.DrawOrbit(sun, planet, scale, orbitColor, 0.0001f);
            
			foreach (var moon in planet.moons)
            {
                GameObject moonContainer = new GameObject("_" + moon.name);
                moonContainer.transform.parent = systemContainer.transform;
                moon.graphic.Create(moon, scale, moonContainer.transform);
                moon.InitReferencesAndVariables();
                moon.references.CreateUI(uiPrefab, moonContainer.transform);
				Utilities.AddActionToButton(moon.references.button, () => Manager.ChangeTarget(moon,SpacePhysics.AstroType.Moon));
                moon.SetPosition(scale);
                SpacePhysics.CalculateOrbitVariables(moon, planet);
                SpacePhysics.DrawOrbit(planet, moon, scale, orbitColor, 0.0001f);
                
            }



        }

		GameObject satelite = new GameObject("_satelite");
		satelite.transform.parent = systemContainer.transform;
		sun.planets [0].moons.Add (SpacePhysics.HohmannTransferSatellite(sun.planets[0],300,scale,satelite.transform,orbitColor,uiPrefab));
	}


    public bool updateRocketOrbit;

    public void Update()
    {
        ManageDirectionalLight();

        if (createTransfer)
        {
            CreateHohmannTransfer(sun.planets[0], sun.planets[1], sun);
            createTransfer = false;
            simulate = false;
        }

	
        if (simulate)
            timer += timerMultiplier * Time.deltaTime;


        foreach (var planet in sun.planets)
        {
            if (planet.oldE != planet.e || planet.oldInc != planet.orbitAngle || planet.oldAscNode != planet.longOfAscNode || planet.oldArgument != planet.argumentOfPeriapsis
                || planet.oldDrawnDegrees != planet.drawnDegrees)
            {
                SpacePhysics.DrawOrbit(sun, planet, scale, orbitColor, 0.0001f);
            }
				
            SpacePhysics.UpdateOrbitWidth(cam.transform, planet, sun, scale,10);
            foreach (var moon in planet.moons)
            {
                SpacePhysics.DrawOrbit(planet, moon, scale, orbitColor, 0.0001f);
                SpacePhysics.UpdateOrbitWidth(cam.transform, moon, planet, scale,0.02f);


            }
            /*
            if (rocket.oldE != rocket.e || rocket.oldInc != rocket.orbitAngle || rocket.oldAscNode != rocket.longOfAscNode || rocket.oldArgument != rocket.argumentOfPeriapsis
                || rocket.oldDrawnDegrees != rocket.drawnDegrees)
            {
                SpacePhysics.DrawOrbit(sun, rocket, scale, orbitColor, 0.0001f);
            }*/


            if (updateRocketOrbit)
            {
                SpacePhysics.DrawOrbit(sun, rocket, scale, orbitColor, 0.0001f);

                updateRocketOrbit = false;
            }

        }


        PrintInfo();

    }

    public void FixedUpdate()
    {
        if (!simulate)
            return;

        SpacePhysics.Rotate(timer, sun);

        foreach (var planet in sun.planets)
        {
            SpacePhysics.Rotate(timer, planet);
            SpacePhysics.MoveThroughOrbit(planet, sun, timer, scale, timerMultiplier);

            foreach (var moon in planet.moons)
            {
                //                SpacePhysics.Rotate(timer, planet);
               SpacePhysics.MoveThroughOrbit(moon, planet, timer, scale, timerMultiplier);

            }

        }

    }


    public void OnGUI()
    {
        UpdateUI(sun,false);

        foreach (var planet in sun.planets)
        {
            UpdateUI(planet,false);

            foreach (var moon in planet.moons)
            {
				UpdateUI(moon,true);

                moon.references.lineRenderer.enabled= (Vector3.Distance(cam.transform.position, moon.graphic.transform.position) < moon.distance / scale * 10);                

            }

        }

    }

    public void UpdateUI(AstroInfo planet,bool hideForMoons)
    {
        if (planet.references.uiT)
        {
            Vector3 direction = planet.graphic.transform.position - cam.transform.position;
            float angle = Vector3.Angle(direction, cam.transform.forward);

            if (angle < 90)
            {
                if (Vector3.Distance(cam.transform.position, planet.graphic.transform.position) < 13.85f * 4 * planet.radius / scale
					||(hideForMoons&& Vector3.Distance(cam.transform.position, planet.graphic.transform.position) > 13.85f * 200 * 1738 / scale))
                {
                    planet.references.canvas.enabled = false;
                }
                else
                {
                    planet.references.canvas.enabled = true;
                }

                planet.references.image.color = planet.graphic.atmoshereTint;
                planet.references.text.text = planet.name;
                Vector3 worldSpace = planet.graphic.transform.position;
                Vector3 viewport = Camera.main.WorldToViewportPoint(planet.graphic.transform.position);
                viewport -= 0.5f * Vector3.one;
                viewport.z = 0;
                Rect rect = planet.references.canvasRT.rect;
                viewport.x *= rect.width;
                viewport.y *= rect.height;
                planet.references.imageRT.localPosition = viewport;
            }
            else
            {
                planet.references.image.color = new Color();
                planet.references.text.text = "";

            }
        }

    }


    public void ManageDirectionalLight()
    {
        directionalLight.enabled = cam.target != sun.graphic.transform;

        directionalLight.transform.LookAt(cam.target);
        Vector3 offset = directionalLight.transform.eulerAngles;
        offset.y += 2;
        directionalLight.transform.eulerAngles = offset;


    }

    public void PrintInfo()
    {

        float h = timer / 3600;
        text.text = h.ToString("F2") + "h       " + "1:" + timerMultiplier + "s\n\n" + current.name + "\nMass: " + current.mass.ToString() + "kg\nPeriod: " + current.rotationalPeriod.ToString()
            + "h\nRadius: " + current.radius.ToString() + "km";

    }



    public void CreateHohmannTransfer(OrbitAstroInfo planet0, OrbitAstroInfo planet1, AstroInfo sun)
    {
        SpacePhysics.HohmannTransfer(planet0, planet1, sun, rocket, scale,orbitColor);

    }

}
