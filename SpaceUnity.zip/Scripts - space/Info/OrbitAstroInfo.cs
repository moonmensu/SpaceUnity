﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class OrbitAstroInfo : AstroInfo {

    //Orbital Elements
    //--a->Semi-major axis (distance)
    //--e->Eccentricity (e)
    //--i->Inclination (orbitAngle) (Ecliptic Plane)
    //--o->Longitude Of The Ascending Node (longOfAscNode)
    //--w->Argument Of Periapsis (argumentOfPeriapsis)
    //--tp->Time Of Periapsis Passage (timeOfPerPass)


    public float distance;//Semi-axis
    [Range(0, 0.99f)]
    public float e = 0;
    [Range(0, 179)]
    public float orbitAngle;

    [Range(0, 360)]
    public float longOfAscNode;
    [Range(0, 360)]
    public float argumentOfPeriapsis;
    public float periapsisVel;




    public float timeOfPerPass;



    [Range(0, 2 * Mathf.PI)]
    public float drawnDegrees = 2 * Mathf.PI;

    //Variables

    [HideInInspector]
    public float T;
    [HideInInspector]
    public float angleOffset;
    [HideInInspector]
    public float b;
    [HideInInspector]
    public float c;
    [HideInInspector]
    public float periapsisDistance;
    [HideInInspector]
    public float apoapsisDistance;

    //Current values

    [HideInInspector]
    public float currentVel = 0;

    [HideInInspector]
    public float currentTheta = 0;


    //Old values
    [HideInInspector]
    public float oldE = 0;
    [HideInInspector]
    public float oldInc = 0;
    [HideInInspector]
    public float oldAscNode = 0;
    [HideInInspector]
    public float oldArgument = 0;
    [HideInInspector]
    public float oldDrawnDegrees = 0;








    public OrbitAstroInfo(string name, float radius, float mass, float period, float distance): base(name, radius, mass,period) 
    {
        this.distance = distance;
    }

    public void SetPosition(float scale)
    {
        scale = 1 / scale;
        graphic.transform.localPosition = Vector3.forward * scale * distance;
    }


    public float R(float theta)
    {
        return (distance * (1 - Mathf.Pow(e, 2))) / (1 + e * Mathf.Cos(theta));

    }

    public Vector3 OrbitWorldPos(float scale, float theta,AstroInfo sun)
    {
        Vector3 localPos = new Vector3(-R(theta) / scale * Mathf.Cos(theta), 0, R(theta) / scale * Mathf.Sin(theta));
        return references.orbitPlane.transform.TransformPoint(localPos)+sun.graphic.transform.position;

    }


    public void InitReferencesAndVariables()
    {

        references.CreateOrbitPlane(graphic.transform.parent);
        c = e * distance;
        b = Mathf.Sqrt(-Mathf.Pow(distance, 2) + Mathf.Pow(c, 2));
        periapsisDistance = distance - c;
        apoapsisDistance = distance + c;



    }



}
