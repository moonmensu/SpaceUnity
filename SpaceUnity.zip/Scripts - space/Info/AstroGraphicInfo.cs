﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class AstroGraphicInfo
{
    public Transform transform;
    public Color atmoshereTint = Color.blue;
    public Texture texture;
    public bool emitLightFromTexture;
    public bool hide = false;


    public float angle = 0;

    public GameObject Create(AstroInfo info, float scale, Transform parent)
    {
		GameObject astro = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        astro.name = info.name;
        scale = 1 / scale;
        astro.transform.localScale = Vector3.one * info.radius * 2 * scale;
        astro.transform.localEulerAngles = Vector3.right * info.axisTilt;
        astro.transform.parent = parent;
        transform = astro.transform;

        //Shaders and graphics
        if (texture)
        {
            Material mat = astro.GetComponent<MeshRenderer>().material;
            mat.SetTexture("_MainTex", texture);
            if (emitLightFromTexture)
            {
                mat.SetTexture("_EmissionMap", texture);
                mat.SetColor("_EmissionColor", Color.white);
                mat.EnableKeyword("_EMISSION");
            }
            else
            {
                mat.shader = Shader.Find("SlinDev/Planet");
                mat.SetColor("_AtmoColor", info.graphic.atmoshereTint);

            }

        }
        return astro;
    }

	/*
	public GameObject Create(AstroInfo info,GameObject prefab, float scale, Transform parent)
	{
		GameObject astro = GameObject.Instantiate(prefab,parent);
		astro.name = info.name;
		scale = 1 / scale;
		astro.transform.localScale = Vector3.one * info.radius * 2 * scale;
		astro.transform.localEulerAngles = Vector3.right * info.axisTilt;
		transform = astro.transform;
		return astro;
	}
	*/






}
