﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlanetInfo : OrbitAstroInfo {

    public List<MoonInfo> moons;


    public PlanetInfo(string name, float radius, float mass,float period,float distance): base(name, radius, mass,period,distance) 
    {
    }

}
