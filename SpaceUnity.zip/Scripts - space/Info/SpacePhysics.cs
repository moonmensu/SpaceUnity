﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpacePhysics
{

    public const float G = 6.674e-11f;



    public static void DrawOrbit(AstroInfo sun, OrbitAstroInfo planet, float scale, Gradient orbitColor, float quality)
    {
        //Relative Planes
        planet.references.orbitPlane.localRotation = Quaternion.identity;
        planet.references.orbitPlane.Rotate(new Vector3(planet.orbitAngle, 0, 0), Space.Self);
        planet.references.orbitPlane.RotateAround(planet.references.orbitPlane.position, -planet.references.orbitPlane.up, planet.argumentOfPeriapsis);
        planet.references.referencePlane.eulerAngles = new Vector3(0, -planet.longOfAscNode, 0);

        //Calculate angle offset
        float angleOffset = 180 - Vector3.Angle(Vector3.right, planet.references.orbitPlane.TransformPoint(Vector3.right));
        Vector3 cross = Vector3.Cross(Vector3.right, planet.references.orbitPlane.TransformPoint(Vector3.right));
        if (cross.y < 0) angleOffset = -angleOffset;
        planet.angleOffset = angleOffset;


        Vector3 sunPos = sun.graphic.transform.position;

        float theta = 0;
        float theta_scale = quality;

        if (planet.references.lineRenderer == null)
        {
            planet.references.CreateLineRenderer(planet, orbitColor, scale);
        }

        theta = planet.angleOffset * Mathf.Deg2Rad;
        int size = (int)((1f / theta_scale) + 1f);
        planet.references.lineRenderer.positionCount = (size);

        //Orbita eliptica
        for (int i = 0; i < size; i++)
        {
            theta += ((planet.drawnDegrees) * theta_scale);
            planet.references.lineRenderer.SetPosition(i, planet.OrbitWorldPos(scale, theta, sun));
        }

        planet.oldE = planet.e;
        planet.oldInc = planet.orbitAngle;
        planet.oldAscNode = planet.longOfAscNode;
        planet.oldArgument = planet.argumentOfPeriapsis;
        planet.oldDrawnDegrees = planet.drawnDegrees;

    }

    public static void UpdateOrbitWidth(Transform cam, OrbitAstroInfo planet, AstroInfo sun, float scale, float maxWidth)
    {
        //Debug.DrawLine(sun.position, planet.transform.position, Color.yellow);
        Vector3 position = cam.position;
        position.y = 0;

        Vector3 relativePos = position;
        Vector3 sunRelPos = sun.graphic.transform.position;
        Vector3 direction = relativePos - sunRelPos;
        direction = direction.normalized;

        //Debug.DrawRay(sun.graphic.transform.position, Vector3.right * planet.distance / scale, Color.green);

        //Angle between camera and sun right
        float theta = 0;
        theta = Vector3.Angle(direction, Vector3.right);
        Vector3 cross = Vector3.Cross(direction, Vector3.right);
        if (cross.y > 0) theta = -theta;
        theta += planet.angleOffset;
        theta *= Mathf.Deg2Rad;

        Vector3 orbitPos = planet.OrbitWorldPos(scale, theta, sun);
        Debug.DrawLine(sun.graphic.transform.position, orbitPos);

        float widthMultiplier = Vector3.Distance(orbitPos, cam.position) / (planet.distance / scale * 150);
        //widthMultiplier = Mathf.Clamp(widthMultiplier, 0, maxWidth);
        planet.references.lineRenderer.widthMultiplier = widthMultiplier;
    }



    public static void MoveThroughOrbit(OrbitAstroInfo info, AstroInfo sun, float timer, float scale, float mult)
    {
        float dt = Time.deltaTime * mult;//delta de tiempo
        float M = sun.mass;//Masa del cuerpo atrayente
        float T = Mathf.Sqrt((4 * Mathf.Pow(Mathf.PI, 2)) / (G / 1e-6f * sun.mass) * Mathf.Pow(info.distance, 3));
        float currentV = Mathf.Sqrt(2 * G * M * (1 / (info.R(info.currentTheta) * 1000) - 1 / (info.distance * 1000 * 2)));

        float theta = currentV / (info.R(info.currentTheta) * 1000) * dt;
        //Debug.Log(theta);

        //float theta =  (-timer / (T * 3.154e+7f) * 360);
        //theta *= Mathf.Deg2Rad;
        info.currentTheta -= theta;

        if (info.currentTheta <= 0)
        {
            info.currentTheta = 2 * Mathf.PI;
        }

        //float v = Mathf.Sqrt(2 * G * M * (1 / r - 1 / (2 * info.distance)));
        //theta=0;
        Vector3 orbitPos = info.OrbitWorldPos(scale, info.currentTheta, sun);
        info.graphic.transform.position = orbitPos;
    }

    public static void Rotate(float timer, AstroInfo info)
    {
        Vector3 rotation = info.graphic.transform.localEulerAngles;
        rotation.y = -timer / (info.rotationalPeriod * 3600) * 360;
        info.graphic.transform.localEulerAngles = rotation;
    }



    public static void CalculateOrbitVariables(OrbitAstroInfo planet, AstroInfo sun)
    {
        planet.periapsisVel = Mathf.Sqrt((2 * G * sun.mass * planet.apoapsisDistance * 1000) / (planet.periapsisDistance * 1000 * (planet.distance * 2 * 1000)));
        planet.currentVel = planet.periapsisVel;
    }



    public static void HohmannTransfer(OrbitAstroInfo planet0, OrbitAstroInfo planet1, AstroInfo sun, OrbitAstroInfo rocket, float scale, Gradient orbitColor)
    {

        float a = (planet0.R(planet0.currentTheta) + planet1.R(planet1.currentTheta)) / 2;
        float a_AU = a * 6.68459e-9f;
        float T = Mathf.Sqrt(Mathf.Pow(a_AU, 3)) / 2;
        float rp = planet0.R(planet0.currentTheta);
        float ra = planet1.R(planet1.currentTheta);
        float e = (ra - rp) / (ra + rp);


        //  rocket.InitReferencesAndVariables();

        rocket.longOfAscNode = Vector3.Angle(planet0.OrbitWorldPos(scale, planet0.currentTheta, sun), planet1.OrbitWorldPos(scale, planet1.currentTheta, sun));
        rocket.distance = a;
        rocket.e = e;



        rocket.InitReferencesAndVariables();
        CalculateOrbitVariables(rocket, sun);
        DrawOrbit(sun, rocket, scale, orbitColor, 0.0001f);

        //DrawOrbit(sun, rocket, scale, orbitColor, 0.0001f);
        rocket.references.lineRenderer.widthMultiplier = 0.005f;

    }


	public static MoonInfo HohmannTransferSatellite(AstroInfo planet,float altitude,float scale,Transform parent,Gradient orbitColor,GameObject uiPrefab){
		MoonInfo satellite=new MoonInfo("satelite", 1, 2800,0,0);
		satellite.distance = altitude + planet.radius;
		satellite.graphic.Create (satellite, scale, parent);
		satellite.InitReferencesAndVariables ();
		CalculateOrbitVariables (satellite, planet);
		satellite.references.CreateUI(uiPrefab, satellite.graphic.transform.parent);
		Utilities.AddActionToButton(satellite.references.button, () => Manager.ChangeTarget(satellite,SpacePhysics.AstroType.Moon));

		return satellite;
	}




	public enum AstroType{Planet=0,Moon=1,Sun=2};


}
