﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;

[System.Serializable]
public class AstroReferences
{

    public LineRenderer lineRenderer = null;
    public Transform referencePlane = null;
    public Transform orbitPlane = null;
    public Transform uiT;
    public RectTransform canvasRT;
    public Canvas canvas;
    public RectTransform imageRT;
    public Image image;
    public Text text;
    public Button button;



    public void CreateLineRenderer(OrbitAstroInfo planet, Gradient orbitColor,float scale)
    {
        if (scale > 1)
            scale = 1 / scale;

        LineRenderer lineRenderer = planet.graphic.transform.gameObject.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Particles/Additive"));

        GradientColorKey[] color = { new GradientColorKey(planet.graphic.atmoshereTint, 0), new GradientColorKey(planet.graphic.atmoshereTint, 1) };
        orbitColor.SetKeys(color, orbitColor.alphaKeys);
        lineRenderer.colorGradient = orbitColor;
        lineRenderer.startWidth = planet.distance*scale;
        lineRenderer.endWidth =planet.distance*scale;
        lineRenderer.widthMultiplier = 1f;
        this.lineRenderer = lineRenderer;
    }

    public void CreateOrbitPlane(Transform parent)
    {
        referencePlane = new GameObject("_reference_plane").transform;
        orbitPlane = new GameObject("_orbit_plane").transform;
        orbitPlane.parent = referencePlane;
        referencePlane.parent = parent;
    }

    public void CreateUI(GameObject uiPrefab, Transform parent)
    {
        uiT = Object.Instantiate(uiPrefab).transform;
        uiT.transform.SetParent(parent);
        canvasRT = uiT.GetComponent<RectTransform>();
        canvas = uiT.GetComponent<Canvas>();
        image = uiT.GetComponentInChildren<Image>();
        imageRT = image.GetComponent<RectTransform>();
        text = uiT.GetComponentInChildren<Text>();
        button = uiT.GetComponentInChildren<Button>();
    }







}
