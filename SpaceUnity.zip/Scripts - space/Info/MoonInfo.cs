﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MoonInfo : OrbitAstroInfo{


    public MoonInfo(string name, float radius, float mass,float period,float distance): base(name, radius, mass,period,distance) 
    {
        this.distance = distance;           
		graphic = new AstroGraphicInfo ();
		references = new AstroReferences ();
    }

    
}
