﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SunInfo : AstroInfo {
    [SerializeField]
    public List<PlanetInfo> planets;


    public SunInfo(string name, float radius, float mass,float period, List<PlanetInfo> planets): base(name, radius, mass,period) 
    {
        this.planets = planets;
    }
}
