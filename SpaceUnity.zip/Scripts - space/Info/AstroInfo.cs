﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class AstroInfo {
    public string name;
    public float radius;//Km
    public float mass;//kg
    public float rotationalPeriod;//h
    public float axisTilt;//deg
    public AstroGraphicInfo graphic;
    [HideInInspector]
    public AstroReferences references;


    public AstroInfo(string name,float radius,float mass,float period)
    {
        this.name = name;
        this.radius = radius;
        this.mass = mass;
        this.rotationalPeriod = period;
    }

    
}
