﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class InfoUI : MonoBehaviour {

	public Text planetNameT;
	public Text infoT;
	public Text dataT;

	public void SetData(AstroInfo info){
		AstroInfoUI infoUI = new AstroInfoUI ();
		infoUI.name = info.name;
		infoUI.data= info.radius+" km";
		infoUI.info = "Radius";
		infoUI= UpdateInfoUI (infoUI,"Mass", info.mass+" kg");

		planetNameT.text = infoUI.name;
		infoT.text = infoUI.info;
		dataT.text = infoUI.data;
	}

	public void SetData(OrbitAstroInfo info,int overload){
		AstroInfoUI infoUI = new AstroInfoUI ();
		infoUI.name = info.name;
		infoUI.data= info.radius+" km";
		infoUI.info = "Radius";	
		infoUI= UpdateInfoUI (infoUI,"Mass", info.mass+" kg");
		infoUI= UpdateInfoUI (infoUI,"Semi-major", info.distance.ToString("F2") +" km");
		infoUI= UpdateInfoUI (infoUI,"Eccentricity", info.e.ToString());
		infoUI= UpdateInfoUI (infoUI,"Asc Node", info.longOfAscNode.ToString());
		infoUI= UpdateInfoUI (infoUI,"Argument", info.argumentOfPeriapsis.ToString());



		planetNameT.text = infoUI.name;
		infoT.text = infoUI.info;
		dataT.text = infoUI.data;
	}





	public AstroInfoUI UpdateInfoUI(AstroInfoUI infoUI,string info,string data){
		infoUI.info += "\n"+info;					
		infoUI.data += "\n"+data;
		return infoUI;
	}


}

[System.Serializable]
public class AstroInfoUI{
	public string name;
	public string info;
	public string data;
}
