﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Manager : MonoBehaviour {
	public static UIManager uiMngr;
	public static PlanetarySystem planetarySystem;
	public static DragCameraLook cam;
	public static AstroInfo currentAstro;
	public static OrbitAstroInfo currentOrbitAstro;

	public void Awake(){
		uiMngr = GetComponent<UIManager>();
		planetarySystem = GetComponent<PlanetarySystem>();
	}

	
	public void Update(){
		
	}


	public static void ChangeTarget(AstroInfo target)
	{
		cam.target = target.graphic.transform;
		currentAstro = target;
		currentOrbitAstro = null;
		cam.distanceMin = target.radius * 4 /planetarySystem.scale;
	}


	public static void ChangeTarget(OrbitAstroInfo target,SpacePhysics.AstroType type)
	{
		cam.target = target.graphic.transform;
		currentAstro = null;
		currentOrbitAstro = target;
		cam.distanceMin = target.radius * 4 /planetarySystem.scale ;
	}

	public static void ChangeTimeStep(float multiplier){
		planetarySystem.timerMultiplier = multiplier;
	}


}
