﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimeSettingsUI : MonoBehaviour {


	public enum TimeRatio{sec,min,hour,day,week,month,year};

	public TimeRatio timeRatio;

	public InputField inputField;
	public Dropdown dropDown;
	public Button button;


	public Sprite simulatingSprite;
	public Sprite pauseSprite;


	public void Awake(){
		inputField = GetComponentInChildren<InputField> ();
		dropDown = GetComponentInChildren<Dropdown> ();	
		button = GetComponentInChildren<Button> ();
		Utilities.AddActionToButton (button, () => PlayStopSimulation ());
	}

	public void Update(){
		timeRatio = (TimeRatio)dropDown.value;	
		AsignToTime ();

	
	}


	public void AsignToTime(){

		if (inputField.text == "" && !inputField.isFocused) {
			inputField.text = Manager.planetarySystem.timerMultiplier.ToString ();
			dropDown.value = 0;
		} else if(inputField.text!="") {

			float inputValue;
			float.TryParse (inputField.text, out inputValue);
			float multiplier = 0;

			switch (timeRatio) {
			case TimeRatio.sec:
				multiplier = inputValue;
				break;
			case TimeRatio.min:
				multiplier = Converter.ConvMinstoSecs (inputValue);
				break;
			case TimeRatio.hour:
				multiplier = Converter.ConvHourstoSecs (inputValue);
				break;
			case TimeRatio.day:
				multiplier = Converter.ConvDaystoSecs (inputValue);
				break;
			case TimeRatio.week:
				multiplier = Converter.ConvWeektoSecs (inputValue);
				break;
			case TimeRatio.month:
				multiplier = Converter.ConvMonthtoSecs (inputValue);
				break;
			case TimeRatio.year:
				multiplier = Converter.ConvYeartoSecs (inputValue);
				break;


			default:
				multiplier = inputValue;
				break;
			}
			Manager.ChangeTimeStep (multiplier);
		}
	
	
	}



	public void PlayStopSimulation(){
		Manager.planetarySystem.simulate =	!Manager.planetarySystem.simulate;
		button.GetComponent<Image> ().sprite = Manager.planetarySystem.simulate ? simulatingSprite : pauseSprite;
			
	
	}



}
